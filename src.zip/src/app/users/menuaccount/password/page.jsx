import Editpass from "@/components/users/Editpass";

export default function AddressPage() {
  return <Editpass />;
}
