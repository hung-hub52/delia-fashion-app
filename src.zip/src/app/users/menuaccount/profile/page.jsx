import Profile from "@/components/users/Profile";

export default function ProfilePage() {
  return <Profile />;
}
