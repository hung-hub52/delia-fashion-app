import Address from "@/components/users/Address";

export default function AddressPage() {
  return <Address />;
}
