import { redirect } from "next/navigation";

export default function Page() {
  redirect("/users/all-products/collection/bracelet-men-1");
  return null;
}
