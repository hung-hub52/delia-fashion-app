import ProductsPage from "@/components/users/ProductsPage";
import { collectionProducts } from "@/data/collections";

export default function Page() {
  let products = collectionProducts["belt"] || [];
  // Lọc đúng theo key thay vì chỉ gender
  products = products.filter(p => p.key === "belt-men");

  return (
    <ProductsPage slug="belt-men" title="Thắt Lưng Pedro Nam" products={products} />
  );
}
