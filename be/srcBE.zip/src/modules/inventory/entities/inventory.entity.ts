import { Entity, PrimaryColumn, Column } from 'typeorm';

@Entity('quan_ly_kho')
export class Inventory {
  @PrimaryColumn({ name: 'id_san_pham', type: 'int' })
  id_san_pham: number;

  @Column({ name: 'ten_san_pham', length: 255 })
  ten_san_pham: string;

  @Column({ name: 'ten_nha_kho', length: 255 })
  ten_nha_kho: string;

  @Column({ name: 'so_luong_ton_kho', type: 'decimal', precision: 10, scale: 2 })
  so_luong_ton_kho: number;

  @Column({ name: 'so_luong_nhap', type: 'int' })
  so_luong_nhap: number;

  @Column({ name: 'created_at', type: 'timestamp' })
  created_at: Date;
}
